package com.example.k8slogviewer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K8sLogViewerApplicationTests {

	@Test
	void contextLoads() {
	}

}
