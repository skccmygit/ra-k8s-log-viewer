package com.example.k8slogviewer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K8sLogViewerApplication {

	public static void main(String[] args) {
		SpringApplication.run(K8sLogViewerApplication.class, args);
	}

}
